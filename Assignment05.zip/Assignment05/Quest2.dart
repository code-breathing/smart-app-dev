class House {
  int id;
  String name;
  double price;

  House(this.id, this.name, this.price);

  void display() {
    print("ID: $id, Name: $name, Price: \$${price}");
  }
}

void main() {
  var h1 = House(1, "Dream Villa", 250000);
  var h2 = House(2, "City Apartment", 180000);
  var h3 = House(3, "Country Home", 120000);

  List<House> houses = [h1, h2, h3];
  for (var house in houses) {
    house.display();
  }
}
