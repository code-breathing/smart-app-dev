enum Gender { male, female, others }

void main() {
  for (var g in Gender.values) {
    print(g);
  }
}
