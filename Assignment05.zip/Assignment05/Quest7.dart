class Question {
  String questionText;
  List<String> options;
  int correctAnswerIndex;

  Question(this.questionText, this.options, this.correctAnswerIndex);

  bool checkAnswer(int userAnswer) {
    return userAnswer == correctAnswerIndex;
  }
}

void main() {
  List<Question> quiz = [
    Question("What is the capital of France?", ["Paris", "London", "Rome"], 0),
    Question("Which planet is known as the Red Planet?", [
      "Earth",
      "Mars",
      "Venus",
    ], 1),
    Question("What is 5 + 3?", ["6", "8", "9"], 1),
  ];

  int score = 0;

  for (var q in quiz) {
    print("\n${q.questionText}");
    for (int i = 0; i < q.options.length; i++) {
      print("${i + 1}. ${q.options[i]}");
    }

    int userAnswer = q.correctAnswerIndex;
    if (q.checkAnswer(userAnswer)) {
      print("Correct!");
      score++;
    } else {
      print("Wrong!");
    }
  }

  print("\nYour final score: $score/${quiz.length}");
}
